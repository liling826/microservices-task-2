﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Movies
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int bookingId { get; set; }
        public string movieName { get; set; }
        public string movieVenue { get; set; }
        public DateTime? movieDateTime { get; set; }

        public int numberOfTickets { get; set; }

        public double? movieAmount { get; set; }

        public string currency { get; set; }
    }
}
