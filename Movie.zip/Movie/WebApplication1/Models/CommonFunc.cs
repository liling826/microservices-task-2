﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class CommonFunc
    {

        public CommonFunc()
        { 
        
        
        }
        public Root GetExchangeRate(string from, string to)
        {
            //HttpClient client = new HttpClient();
            //client.BaseAddress = new Uri("https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/");
            //client.DefaultRequestHeaders.Accept.Clear();
            //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            ////GET Method
            //Task<HttpResponseMessage> response = client.GetStringAsync(from+"/sgd.json");
            //var repositories=JsonConvert.DeserializeObject<Root>(response.Result.Content.ToString());
            ////HttpClient client = new HttpClient();
            ////var streamTask = client.GetStringAsync("https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/" + from + "/sgd.json");
            ////var repositories = JsonConvert.DeserializeObject<Root>(streamTask.ToString());
            //return repositories;
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            WebClient wb = new WebClient();
            wb.Headers.Add("User-Agent: Other");
            string json = wb.DownloadString("https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/" + from + "/sgd.json");
            var repositories = JsonConvert.DeserializeObject<Root>(json);
            return repositories;
        }
    }
}
